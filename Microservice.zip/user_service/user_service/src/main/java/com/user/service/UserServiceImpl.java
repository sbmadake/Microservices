package com.user.service;

import com.user.entity.User;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class UserServiceImpl implements  UserService{

    List<User> list= Arrays.asList(
        new User(101l,"Tanish","7645465656"),
            new User(102l,"Manish","45678787"),
            new User(103l,"Anish","67687877"),
            new User(104l,"Kranti","56576675"),
            new User(105l,"Eshan","3456576676"),
            new User(106l,"Kumati","7676456345")
    );

    @Override
    public User getUser(Long id) {
      return this.list.stream().filter(user->user.getUserId().equals(id)).findAny().orElse(null);
    }
}
