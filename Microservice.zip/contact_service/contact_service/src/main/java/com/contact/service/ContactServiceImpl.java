package com.contact.service;

import com.contact.entity.Contact;
import org.springframework.stereotype.Service;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
@Service
public class ContactServiceImpl implements ContactService{
    List<Contact> list= Arrays.asList(
            new Contact(1l,"abc@gmail.com","Paresh mishra",101L),
            new Contact(2l,"xyz@gmail.com","Minal Patil",102L),
            new Contact(3l,"pqr@gmail.com","Kranti shah",103L),
            new Contact(1l,"abc@gmail.com","Paresh mishra",101L)
    );
    @Override
    public List<Contact> getContactsofUser(Long userId) {
        return list.stream().filter(contact -> contact.getUserId().equals(userId)).collect(Collectors.toList());
    }
}
